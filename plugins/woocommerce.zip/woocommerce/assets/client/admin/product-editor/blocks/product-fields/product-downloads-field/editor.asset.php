<?php return array('version' => '26347576057a9883f0ea');
